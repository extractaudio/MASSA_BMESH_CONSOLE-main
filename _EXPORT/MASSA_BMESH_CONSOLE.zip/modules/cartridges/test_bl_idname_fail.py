class Test:
    bl_idname = ("test.tuple",)
    bl_idname_valid = "test.string"
