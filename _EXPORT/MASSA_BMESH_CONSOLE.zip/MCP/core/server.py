from mcp.server.fastmcp import FastMCP

def create_mcp_server():
    return FastMCP("Massa_Modular_Architect")
